Version 0.2
Minor bug fixes (andateveli a cercare nel codice)